addLayer("a", {
    name: "Achievements", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "A", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0),
        }
    },
    color: "#FC190E",
    requires: new Decimal(10), // Can be a function that takes requirement increases into account
    resource: "Achievements", // Name of prestige currency
    type: "none", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    row: 'side', // Row the layer is in on the tree (0 is the first row)
    layerShown() { return true },
    achievements: {
        11: {
            name: 'You gotta start somewhere.',
            done() { return getBuyableAmount('n', 11).gte(1) },
            tooltip: "Reach Successor Level 1",
        },
        12: {
            name: 'Operation Level 1',
            done() { return getBuyableAmount('n', 12).gte(1) },
            tooltip: "Reach Addition Level 1",
        },
        13: {
            name: 'Operation Level 2',
            done() { return getBuyableAmount('n', 13).gte(1) },
            tooltip: "Reach Multiplication Level 2",
        },
        14: {
            name: '100 points per second is a lot.',
            done() { return getPointGen().gte(100) },
            tooltip: "Have your points generation reached 100/s.\nReward:Unlocks an upgrade to increase your hardcaps.",
        },
        15: {
            name: 'ONE BILLION!',
            done() { return player.points.gte(1e9) },
            tooltip: "Have 1e9 points.\nReward:Unlocks an upgrade to increase your points hardcap.",
        },
        16: {
            name: 'Geometry learner',
            done() { return getBuyableAmount('n', 21).gte(5) },
            tooltip: "Reach Euclidean Plane Level 5.\nReward:Unlocks Line and Circle.",
        },
        21: {
            name: 'I need to study.',
            done() { return player.r.points.gte(1) },
            tooltip: "Reset for at least 1 Research Points.\nReward:Doubles numbers gain.",
        },
        22: {
            name: 'Successor sucks.',
            done() { return getBuyableAmount('n', 11).gte(100) },
            tooltip: "Reach Successor Level 100.\nReward:Multiply Successor effect by x10000.",
        },
        23: {
            name: 'Multiplication sucks.',
            done() { return getBuyableAmount('n', 13).gte(100) },
            tooltip: "Reach Multiplication Level 100.\nReward:Multiplication effect is squared.",
        },
        24: {
            name: 'Math Beginner',
            done() { return getTotalBuyables('n').gte(500) },
            tooltip: "Have more than 500 number buyable levels.",
        },
        25: {
            name: 'Age of Automation',
            done() { return hasUpgrade('r', 14) },
            tooltip: "Have all four QOL upgrades in the fitst row.",
        },
        26: {
            name: 'Primes Less than 100',
            done() { return getBuyableAmount('n',31).gte(25) },
            tooltip: "Reach Prime Number Level 25.",
        },
        31: {
            name: 'Easy',
            done() { return hasChallenge('c', 11) },
            tooltip: "Complete \"No Geometry\" once.",
        },
        32: {
            name: 'Not so easy',
            done() { return hasChallenge('c', 12) },
            tooltip: "Complete \"No Arithmetics\" once.",
        },
        33: {
            name: 'The universe can\'t hold you!',
            done() { return player.points.gte(1e80) },
            tooltip: "Have 1e80 points.\n Reward: unlocks another upgrade to increase your hardcap.",
        },
        34: {
            name: 'Hard',
            done() { return hasChallenge('c', 21) },
            tooltip: "Complete \"Less Numbers\" once.",
        },
        35: {
            name: 'Extremely Hard',
            done() { return hasChallenge('c', 22) },
            tooltip: "Complete \"Instant softcap\" once.",
        },
        36: {
            name: 'Googol',
            done() { return player.points.gte(1e100) },
            tooltip: "Have 1e100 points.",
        },
        41: {
            name: 'Nice.',
            done() { return player.c.points.gte(6.9) },
            tooltip: "Have 6.9 RankingScore.",
        },
        42: {
            name: 'THIS IS NOT ANTIMATTER DIMENSIONS!',
            done() { return getGridData('v',201).amount.gte(1) },
            tooltip: "Buy 1 R<sup>2</sup>.",
        },
        43: {
            name: 'Four-dimensional being',
            done() { return getGridData('v',401).amount.gte(1) },
            tooltip: "Buy 1 R<sup>4</sup>.",
        },
        44: {
            name: 'The 9th Dimension is a lie',
            done() { return getGridData('v',801).amount.gte(1) },
            tooltip: "Buy 1 R<sup>8</sup>.",
        },
        45: {
            name: 'Vector Space Mastery',
            done() { return hasChallenge('c',41) },
            tooltip: "Complete \"No Numbers I\" once",
        },
        51: {
            name: 'Its not a REAL game!',
            done() { return player.i.points.gte(1) },
            tooltip: "Gain 1 Imaginary points",
        },
        52: {
            name: 'Double happiness',
            done() { return tmp.i.getTotalActivate()>=2 },
            tooltip: "Activate 2 imaginary perks at once",
        },
        53: {
            name: 'Complex Number Mastery',
            done() { return hasChallenge('c',42) },
            tooltip: "Complete \"No Numbers II\" once",
        },
        54: {
            name: 'Math needs imagination',
            done() { return player.i.points.gte(1e25) },
            tooltip: "Gain 1e25 Imaginary points",
        },
        56: {
            name: 'All your layers belong to us',
            done() { return hasUpgrade('r',51)&&hasUpgrade('r',52) },
            tooltip: "Unlock all row-2 layers.",
        },
        61: {
            name: 'Almost Impossible',
            done() { return hasChallenge('c',31) },
            tooltip: "Complete \'Limited Buyables'\ once.",
        },
        62: {
            name: 'Is it hard to get double-star?',
            done() { return player.c.points.gte(12.66) },
            tooltip: "Have 12.66 RankingScore.",
        },
        63: {
            name: 'Triple googol',
            done() { return player.c.bestScore[11].gte(1e100)&&player.c.bestScore[12].gte(1e100)&&player.c.bestScore[21].gte(1e100) },
            tooltip: "Have your best score in C1~C3 exceed 1e100.",
        },
        64: {
            name: 'YOU',
            done() { return player.c.points.gte(16) },
            tooltip: "Have 16 RankingScore.",
        },
        65: {
            name: 'Worst Suffering',
            done() { return hasChallenge('c',32) },
            tooltip: "Complete \'Negative RankingScore'\ once.",
        },
        66: {
            name: 'INFINITY!',
            done() { return player.points.gte("1.79e308") },
            tooltip: "Have infinity points.\nReward: unlocks a new layer",
        },
        71: {
            name: 'A new beginning',
            done() { return player.inf.points.gte(1) },
            tooltip: "Reset and gain at lease 1 Infinity Points.\nReward:You Win!",
        },
    },
    updateAchievements() {
        let count = 0
        let total = player.a.achievements.length
        for (let i = 0; i < total; ++i) {
            if (hasAchievement('a', player.a.achievements[i])) {
                ++count
            }
        }
        player.a.points = new Decimal(count)
    }
})