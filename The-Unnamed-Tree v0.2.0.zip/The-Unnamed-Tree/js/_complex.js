addLayer("i", {
    name: "Complex Numbers", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "I", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0),
            direction: 0,
            maxActivate: 1
        }
    },
    color: "#C0C0C0",
    requires: new Decimal(10), // Can be a function that takes requirement increases into account
    resource: "Imaginary Points", // Name of prestige currency
    baseResource: "points", // Name of resource prestige is based on
    baseAmount() { return player.points }, // Get the current amount of baseResource
    type: "none", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    row: 1, // Row the layer is in on the tree (0 is the first row)
    layerShown() { return hasUpgrade('r', 52) },
    branches: ['n'],
    tabFormat: [
        "main-display",
        "blank",
        ["display-text", () => { return "Your production direction is " + player.i.direction + "°" }],
        ["display-text", () => {
            return "So your point production ^" + (1 - player.i.direction / 90).toFixed(4)
                + ", and then x" + Math.cos(player.i.direction * Math.PI / 180).toFixed(4)
        }],
        ["display-text", () => {
            return "But you will also gain "
                + format(tmp.i.getIPGen(player.i.direction))
                + " Imaginary Points per second(Based on points)"
        }],
        ["display-text", () => {
            return "Your IP producion is ^" +format(tmp.i.getIPexp(),4)
                + ", and then x" + Math.sin(player.i.direction * Math.PI / 180).toFixed(4)
        }],
        ["display-text", () => { if(inChallenge('c',42)) return "You are producing "+format(tmp.i.getIPGen())+" Numbers per second" }],
        ["display-text","Your iP production is also affected by the softcap of points!"],
        "blank",
        ["slider", ["direction", 0, 90]],
        "blank",
        ["display-text", () => { if (hasUpgrade('i', 11)) return "You can choose " + tmp.i.getTotalActivate().toString() + "/" + player.i.maxActivate + " perks to activate" }],
        "clickables",
        "upgrades"
    ],

    clickables: {
        11: {
            title() { return "Algebraic form (" + (getClickableState('i', this.id) == "ON" ? "ON" : "OFF") + ")" },
            display() { return "Increases real and imaginary point gain by x" + format(this.effect()) },
            canClick() { return (tmp.i.getTotalActivate() < player.i.maxActivate) || getClickableState('i', this.id) == "ON" },
            effect() { return player.i.points.add(1).pow(0.25) },
            unlocked() { return hasUpgrade('i', 11) },
            tooltip: "a+bi",
            onClick() { setClickableState('i', this.id, (getClickableState('i', this.id) == "ON" ? "OFF" : "ON")) },
            masterButtonPress() { },
            style: { "width": "200px" }
        },
        12: {
            title() { return "Geometric form (" + (getClickableState('i', this.id) == "ON" ? "ON" : "OFF") + ")" },
            display() { return "Increases Euclidean Plane effect base by +" + format(this.effect()) },
            canClick() { return (tmp.i.getTotalActivate() < player.i.maxActivate) || getClickableState('i', this.id) == "ON" },
            effect() {
                let effect = player.i.points.add(1).log10()
                if (hasUpgrade('i', 14)) effect = effect.times(upgradeEffect('i', 14))
                return effect
            },
            unlocked() { return hasUpgrade('i', 12) },
            tooltip: "(a,b) in complex plane",
            onClick() { setClickableState('i', this.id, (getClickableState('i', this.id) == "ON" ? "OFF" : "ON")) },
            masterButtonPress() { },
            style: { "width": "200px" }
        },
        13: {
            title() { return "Trigonometric form (" + (getClickableState('i', this.id) == "ON" ? "ON" : "OFF") + ")" },
            display() { return "Increases \"Trigonometric function\" effect by x" + format(this.effect()) },
            canClick() { return (tmp.i.getTotalActivate() < player.i.maxActivate) || getClickableState('i', this.id) == "ON" },
            effect() { return player.i.points.add(1).pow(0.2) },
            unlocked() { return hasUpgrade('i', 15) },
            tooltip: "r(cosθ+isinθ)",
            onClick() { setClickableState('i', this.id, (getClickableState('i', this.id) == "ON" ? "OFF" : "ON")) },
            masterButtonPress() { },
            style: { "width": "200px" }
        },
        21: {
            title() { return "Exponent form (" + (getClickableState('i', this.id) == "ON" ? "ON" : "OFF") + ")" },
            display() { return "Increases \"Exponent\" Research effect by +" + format(this.effect(), 4) },
            canClick() { return (tmp.i.getTotalActivate() < player.i.maxActivate) || getClickableState('i', this.id) == "ON" },
            effect() { return player.i.points.add(1).log10().div(500).min(0.2) },
            unlocked() { return hasUpgrade('i', 21) },
            tooltip: "re<sup>iθ</sup>",
            onClick() { setClickableState('i', this.id, (getClickableState('i', this.id) == "ON" ? "OFF" : "ON")) },
            masterButtonPress() { },
            style: { "width": "200px" }
        },
    },
    upgrades: {
        11: {
            title: "Algebraic form",
            description: "Unlocks a perk",
            cost: new Decimal(10000)
        },
        12: {
            title: "Geometric form",
            description: "Unlocks the second perk",
            unlocked() { return hasUpgrade('i', 11) },
            cost: new Decimal(100000)
        },
        13: {
            title: "Complex multiplication",
            description: "Algebraic form also boost Multiplication",
            effect() { return clickableEffect('i', 11).ln() },
            effectDisplay() { return "+" + format(this.effect()) },
            unlocked() { return hasUpgrade('i', 11) },
            cost: new Decimal(1e6)
        },
        14: {
            title: "Complex Plane",
            description: "Increase Geometric Form effect based on EP level",
            effect() { return getBuyableAmount('n', 21).div(50).add(1) },
            effectDisplay() { return "x" + format(this.effect()) },
            unlocked() { return hasUpgrade('i', 12) },
            cost: new Decimal(1e7)
        },
        15: {
            title: "Trigonometric form",
            description: "Unlocks the third perk",
            unlocked() { return hasUpgrade('i', 13) && hasUpgrade('i', 14) },
            cost: new Decimal(1e8)
        },
        16: {
            title: "Complex conjugation",
            description: "You can choose another perk to activate",
            unlocked() { return hasUpgrade('i', 15) },
            cost: new Decimal(1e9)
        },
        21: {
            title: "Exponent form",
            description: "Unlocks the fourth perk",
            unlocked() { return hasUpgrade('i', 16) },
            cost: new Decimal(1e10)
        },
        22: {
            title: "Complex Exponent",
            description: "Exponent form will also affect iP exponent",
            unlocked() { return hasUpgrade('i', 21) },
            cost: new Decimal(1e14)
        },
        23: {
            title: "Complex-Vector Synergy",
            description: "Increases iP gain based on scalars",
            effect() { return player.v.points.add(1).log10() },
            effectDisplay() { return "x" + format(this.effect()) },
            unlocked() { return hasUpgrade('i', 22)&&hasUpgrade('r',51) },
            cost: new Decimal(1e20)
        },
    },
    getIPexp(){
        let exp=new Decimal(player.i.direction / 900)
        if(hasChallenge('c',42)) exp=exp.times(challengeEffect('c',42).exp)
        if(hasUpgrade('i',22)&&(getClickableState('i',21)=="ON")) exp=exp.add(clickableEffect('i',21))
        return exp
    },
    getIPGen() {
        let pps = getPointGen()
        pps = pps.pow(tmp.i.getIPexp()).times(Math.sin(player.i.direction * Math.PI / 180))
        if (getClickableState('i', 11) == "ON") pps = pps.times(clickableEffect("i", 11))
        if (hasMilestone('c', 5)) pps = pps.times(player.c.points.add(1))
        if (hasUpgrade('i', 23)) pps = pps.times(upgradeEffect('i',23))
        pps = softcap(pps, player.productionHardCap, new Decimal(0.5))
		pps = softcap(pps, getSuperSoftcap(), new Decimal(0.4))
        return pps
    },
    getTotalActivate() {
        let j = 0
        for (let k in player.i.clickables) {
            if (getClickableState('i', k) == "ON") ++j
        }
        return j
    },
    getMaxActivate(){
        let maxa=1
        if(hasUpgrade('i',16)) maxa+=1
        if(hasChallenge('c',42)) maxa+=1
        player.i.maxActivate=maxa
    },
    update(diff) {
        player.i.points = player.i.points.add(tmp.i.getIPGen().times(diff))
        if(inChallenge('c',42))player.n.points = player.n.points.add(tmp.i.getIPGen().times(diff))
    }
})