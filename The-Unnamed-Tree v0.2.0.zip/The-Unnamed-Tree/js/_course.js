addLayer("c", {
    name: "Course", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "C", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() {
        return {
            unlocked: false,
            points: new Decimal(0),
            bestScore: {
                11: new Decimal(0),
                12: new Decimal(0),
                21: new Decimal(0),
                22: new Decimal(0),
                31: new Decimal(0),
                32: new Decimal(0),
                41: new Decimal(0),
                42: new Decimal(0),
            }
        }
    },
    color: "#EA3FF7",
    requires: new Decimal(10), // Can be a function that takes requirement increases into account
    resource: "RankingScore", // Name of prestige currency
    type: "none", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    row: 2, // Row the layer is in on the tree (0 is the first row)
    layerShown() { return hasUpgrade('r',36) },
    tooltip(){return (format(player.c.points,4)+' RKS')},
    branches:['i','r','v'],
    tabFormat:{
        "Challenges":{
            content:[
                ["main-display-RKS",4],
                "blank",
                ["display-text","Get more points in challenges to gain RankingScore!"],
                ["display-text","Entering any challenge will cause a Research reset!"],
                "blank",
                "challenges"
            ]
        },
        "Rewards":{
            content:[
                ["main-display-RKS",4],
                "blank",
                ["display-text","You have unlocked the following rewards:"],
                "milestones"
            ]
        }
    },
    challenges:{
        11:{
            name:"No Geometry",
            challengeDescription: "Geometric buyables(21~23) are disabled",
            goalDescription(){return "1e15 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"Increase Multiplication exponent.",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(1e15)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(1e15)).sub(1).times(2).add(1).max(0)
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', Mult exponent +'+format(this.rewardEffect().exp,2))},
            canComplete(){return player.points.gte(1e15)},
            onEnter(){doReset('r')},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
        12:{
            name:"No Arithmetics",
            challengeDescription: "Arithmetic buyables(12~13) are disabled",
            goalDescription(){return "1e25 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"Unlocks 3 researches, and improve Circle's formula.",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(1e25)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(1e25)).times(2)
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', Circle effect exponent +'+format(this.rewardEffect().exp,2))},
            canComplete(){return player.points.gte(1e25)},
            onEnter(){doReset('r')},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
        21:{
            name:"Less Numbers",
            challengeDescription: "Number gain^0.5",
            goalDescription(){return "1e50 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"Increase number exponent.",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(1e50)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(1e50)).div(5).sub(0.15).max(0)
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', number exponent +'+format(this.rewardEffect().exp,4))},
            unlocked(){return hasChallenge('c',11)&&hasChallenge('c',12)},
            canComplete(){return player.points.gte(1e50)},
            onEnter(){doReset('r')},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
        22:{
            name:"Instant softcap",
            challengeDescription: "softcap and super softcap start at 1",
            goalDescription(){return "2.22e22 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"Unlocks a research, and delay your softcap, and...maybe new layers?",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(2.22e22)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(2.22e22)).div(10).add(1)
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', softcap delayed by ^'+format(this.rewardEffect().exp))},
            unlocked(){return hasChallenge('c',21)&&hasUpgrade('n',23)},
            canComplete(){return player.points.gte(2.22e22)},
            onEnter(){doReset('r')},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
        31:{
            name:"Limited Buyables",
            challengeDescription: "You can buy only 20 buyables",
            goalDescription(){return "1e50 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"Gain free buyable levels in the first two rows, except addition(You know why)",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(1e50)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(1e50)).times(6).sub(4).max(0),
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', +'+format(this.rewardEffect().exp)+" free levels")},
            unlocked(){return hasChallenge('c',22)},
            canComplete(){return player.points.gte(1e50)},
            onEnter(){doReset('r')},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
        32:{
            name:"Negative RankingScore",
            challengeDescription: "RankingScore is stuck at -0.95",
            goalDescription(){return "1e40 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"Multiply total RankingScore",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(1e40)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(1e40)).times(0.1).add(1),
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', total RKS x'+format(this.rewardEffect().exp))},
            unlocked(){return hasChallenge('c',31)&&hasMilestone('c',6)},
            canComplete(){return player.points.gte(1e40)},
            onEnter(){doReset('r')},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
        41:{
            name:"No Numbers I",
            challengeDescription: "You can't normally gain numbers, but R<sup>1</sup> will produce them<br>Entering this challenge does a dimensional shift.",
            goalDescription(){return "1e75 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"Scalar to Number exponent+0.1, Multiply R<sup>8</sup> production, and re-unlock Complex Number.",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(1e75)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(1e75)).add(0.2).pow(4).max(1),
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', R<sup>8</sup> production x'+format(this.rewardEffect().exp))},
            unlocked(){return hasChallenge('c',32)},
            canComplete(){return player.points.gte(1e75)},
            onEnter(){doReset('r');dimShift()},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
        42:{
            name:"No Numbers II",
            challengeDescription: "You can't normally gain numbers, but you will get them when you produce iP.<br>Entering thes challenge will reset your iP amount",
            goalDescription(){return "1e75 points (Your best is "+format(player.c.bestScore[this.id])+')'},
            rewardDescription:"You can activate another perk, increase your iP exponent, and re-unlock Vector Space",
            rewardEffect(){return {
                'rks':getRKS(player.c.bestScore[this.id],new Decimal(1e75)),
                'exp':getRKS(player.c.bestScore[this.id],new Decimal(1e75)).times(0.2).add(1),
            }},
            rewardDisplay(){return ('RKS+'+format(this.rewardEffect().rks,4)+', iP exponent x'+format(this.rewardEffect().exp))},
            unlocked(){return hasChallenge('c',32)},
            canComplete(){return player.points.gte(1e75)},
            onEnter(){doReset('r');player.i.points=new Decimal(0)},
            onExit(){player.c.bestScore[this.id]=player.c.bestScore[this.id].max(player.points)}
        },
    },
    milestones:{
        0:{
            requirementDescription:'1.00 RankingScore',
            effectDescription(){return 'Multiplying points gain by (1+RKS)^8<br>Currently: x'+format(player.c.points.add(1).pow(8))},
            done(){return player.c.points.gte(1)}
        },
        1:{
            requirementDescription:'3.00 RankingScore',
            effectDescription(){return 'Multiplying number gain by (1+RKS)^4<br>Currently: x'+format(player.c.points.add(1).pow(4))},
            done(){return player.c.points.gte(3)},
            unlocked(){return hasMilestone('c',0)}
        },
        2:{
            requirementDescription:'5.00 RankingScore',
            effectDescription(){return 'Multiplying RP gain by (1+RKS)^2<br>Currently: x'+format(player.c.points.add(1).pow(2))},
            done(){return player.c.points.gte(5)},
            unlocked(){return hasMilestone('c',1)}
        },
        3:{
            requirementDescription:'7.00 RankingScore',
            effectDescription(){return 'Gain 10% RP per second.'},
            done(){return player.c.points.gte(7)},
            unlocked(){return hasMilestone('c',2)}
        },
        4:{
            requirementDescription:'9.00 RankingScore, Vector Space Unlocked',
            effectDescription(){return 'Multiplying all dimensions production by (RKS+1)^0.5<br>Currently: x'+format(player.c.points.add(1).pow(0.5))},
            done(){return player.c.points.gte(9)&&hasUpgrade('r',51)},
            unlocked(){return hasMilestone('c',3)}
        },
        5:{
            requirementDescription:'9.00 RankingScore, Complex Number Unlocked',
            effectDescription(){return 'Multiplying Imaginary point gain by (RKS+1)<br>Currently: x'+format(player.c.points.add(1))},
            done(){return player.c.points.gte(9)&&hasUpgrade('r',52)},
            unlocked(){return hasMilestone('c',3)}
        },
        6:{
            requirementDescription:'11.00 RankingScore',
            effectDescription(){return 'Points gain exponent +(RKS-11)x5% in challenges,capped at 1.10<br>currently: ^'+format(player.c.points.sub(11).times(0.05).add(1).min(1.10),4)},
            done(){return player.c.points.gte(11)},
            unlocked(){return hasMilestone('c',4)||hasMilestone('c',5)}
        },
    },
    getTotalRKS(){
        let rks=new Decimal(0)
        for (let i in player.c.challenges) {
            rks=rks.add(challengeEffect('c',i).rks)
        }
        if(hasChallenge('c',32)) rks=rks.times(challengeEffect('c',32).exp)
        if(inChallenge('c',32)) rks=new Decimal(-0.95)
        player.c.points=rks
    }
})