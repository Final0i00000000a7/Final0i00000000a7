addLayer("n", {
    name: "Number", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "N", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0),
        }
    },
    color: "#4BDC13",
    requires: new Decimal(10), // Can be a function that takes requirement increases into account
    resource: "numbers", // Name of prestige currency
    baseResource: "points", // Name of resource prestige is based on
    baseAmount() { return player.points }, // Get the current amount of baseResource
    type: "normal", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    exponent: 0.5, // Prestige currency exponent
    gainMult() { // Calculate the multiplier for main currency from bonuses
        mult = new Decimal(1).times(buyableEffect('n', 31))
        if (hasUpgrade('n', 16)) mult = mult.times(upgradeEffect('n', 16))
        if (hasAchievement('a', 21)) mult = mult.times(2)
        if (hasMilestone('c', 1)) mult = mult.times(player.c.points.add(1).pow(4))
        if (layerunlocked('v')) mult = mult.times(tmp.v.effect)
        if (inChallenge('c',41)||inChallenge('c',42)) mult=new Decimal(0)
        return mult
    },
    gainExp() { // Calculate the exponent on main currency from bonuses
        let exp = new Decimal(1)
        if (hasUpgrade('r', 33)) exp = exp.times(upgradeEffect('r', 33))
        if (hasChallenge('c', 21)) exp = exp.add(challengeEffect('c', 21).exp)
        if (inChallenge('c', 21)) exp = exp.times(0.5)
        return exp
    },
    row: 0, // Row the layer is in on the tree (0 is the first row)
    hotkeys: [
        { key: "n", description: "N: Reset for numbers", onPress() { if (canReset(this.layer)) doReset(this.layer) } },
    ],
    layerShown() { return true },
    automate() {
        if (hasUpgrade('r', 13) && getClickableState('tg', 11) != "OFF") {
            for (let i in player.n.buyables) {
                for (let j = 0; j < 10; ++j) {
                    if (i != '21' || !layerunlocked('tg') || getBuyableAmount('n', 21).lt(player.tg.maxEP) || player.tg.maxEP.lt(0)) buyBuyable('n', i)
                }
            }
        }
    },
    passiveGeneration() {
        let base = new Decimal(0)
        if (hasUpgrade('r', 14)) {
            base = base.add(new Decimal(1))
        }
        return base
    },
    doReset(resetLayer) {
        if (tmp[resetLayer].row > 0) {
            let keeps = []
            if (hasUpgrade('r', 12)) {
                keeps.push('upgrades')
            }
            layerDataReset('n', keeps)
            if (hasUpgrade('r', 11) && !hasUpgrade('r', 12)) {
                player.n.upgrades.push(13)
                player.n.upgrades.push(15)
                player.n.upgrades.push(21)
            }
        }
    },
    upgrades: {
        11: {
            title: "Counting",
            description: "Unlocks a buyable",
            cost: new Decimal(1),
        },
        12: {
            title: "Basic Arithmetic",
            description: "Unlocks Addition and Multiplication",
            cost: new Decimal(5),
            unlocked() { return hasUpgrade('r', 12) || (hasUpgrade('n', 11) && getBuyableAmount('n', 11).gte(5)) },
        },
        13: {
            title: "Decimal Notation",
            description: "Increases your hardcaps to 1e9.",
            cost: new Decimal(100),
            unlocked() { return hasUpgrade('n', 12) && hasAchievement('a', 14) },
        },
        14: {
            title: "Geometry",
            description: "Unlocks geometric buyables.",
            cost: new Decimal(1000),
            unlocked() { return hasUpgrade('n', 13) },
        },
        15: {
            title: "Scientific Notation",
            description: "Increases your points hardcap to 1e80.",
            cost: new Decimal(114514),
            unlocked() { return hasUpgrade('n', 14) && hasAchievement('a', 15) },
        },
        16: {
            title: "Shape-Number Synergy",
            description: "Increases numbers gain based on EP Level.",
            cost: new Decimal(500000),
            unlocked() { return hasUpgrade('n', 14) },
            effect() { return getBuyableAmount('n', 21).add(1) },
            effectDisplay() { return format(upgradeEffect(this.layer, this.id)) + "x" },
        },
        21: {
            title: "Overflow I",
            description: "Turns your points production hardcap into softcap.",
            cost: new Decimal(1919810),
            unlocked() { return hasUpgrade('n', 15) },
        },
        22: {
            title: "Research",
            description: "Unlocks a new layer.",
            cost: new Decimal(1e9),
            unlocked() { return hasUpgrade('n', 15) && hasUpgrade('n', 16) && hasUpgrade('n', 21) },
        },
        23: {
            title: "Overflow II",
            description: "Increase your point hardcap to 1.79e308, but your point production will have a SUPER SOFTCAP.",
            cost: new Decimal(1e50),
            unlocked() { return hasAchievement('a', 33) && hasUpgrade('n', 21) },
        },

    },
    buyables: {
        11: {
            title: "Successor",
            display() {
                return ("\nGain +1 points per second.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Cost: " + format(this.cost()) + " numbers\n"
                    + "Effect: +" + format(this.effect()))
            },
            cost(x) {
                let cost = new Decimal(x)
                if (x.gte(10)) {
                    cost = costWithSoftCap(new Decimal(x).sub(10), new Decimal(1), new Decimal(1.1)
                        , [[new Decimal(90), new Decimal(1.2)],
                        [new Decimal(190), new Decimal(1.5)],
                        [new Decimal(400), new Decimal(2)],
                        [new Decimal(1000), new Decimal(3)],
                        ]).times(cost)
                }
                return cost.div(buyableEffect('n', 32)).round()
            },
            unlocked() { return hasUpgrade('n', 11) },
            effect(x) {
                if (hasChallenge('c', 31)) x = x.add(challengeEffect('c', 31).exp)
                let effect = new Decimal(x)
                if (hasAchievement('a', 22)) {
                    effect = effect.times(10000)
                }
                return effect
            },
            canAfford() {
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && player[this.layer].points.gte(this.cost())
            },
            buy() {
                if (!hasUpgrade('r', 13)) player[this.layer].points = player[this.layer].points.sub(this.cost())
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
        12: {
            title: "Addition",
            display() {
                return ("\nGain points per second based on numbers.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Cost: " + format(this.cost()) + " numbers\n"
                    + "Effect: +" + format(this.effect()))
            },
            cost(x) {
                let cost = new Decimal(x).add(2).pow(2)
                if (x.gte(10)) {
                    cost = costWithSoftCap(new Decimal(x).sub(10), new Decimal(1), new Decimal(1.25)
                        , [[new Decimal(90), new Decimal(1.2)],
                        [new Decimal(190), new Decimal(1.5)],
                        [new Decimal(400), new Decimal(2)],
                        [new Decimal(1000), new Decimal(3)],
                        ]).times(cost)
                }
                return cost.div(buyableEffect('n', 32)).round()
            },
            effect(x) {
                return new Decimal(player[this.layer].points).add(1).times(x)
            },
            unlocked() { return hasUpgrade('n', 12) },
            canAfford() {
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && !inChallenge('c', 12)
                    && player[this.layer].points.gte(this.cost())
            },
            buy() {
                if (!hasUpgrade('r', 13)) player[this.layer].points = player[this.layer].points.sub(this.cost())
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
        13: {
            title: "Multiplication",
            display() {
                return ("\nMultiply points gain.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Cost: " + format(this.cost()) + " numbers\n"
                    + "Effect: x" + format(this.effect()))
            },
            cost(x) {
                let cost = costWithSoftCap(x, new Decimal(10), new Decimal(1.2), standardSoftcap)
                return cost.div(buyableEffect('n', 32)).round()
            },
            effect(x) {
                if (hasChallenge('c', 31)) x = x.add(challengeEffect('c', 31).exp)
                effect = new Decimal(x).add(1)
                let exp1 = new Decimal(1)
                if (hasAchievement('a', 23)) exp1 = exp1.add(1)
                if (hasChallenge('c', 11)) exp1 = exp1.add(challengeEffect('c', 11).exp)
                if (hasUpgrade('i', 13) && (getClickableState('i', 11) == "ON")) exp1 = exp1.add(upgradeEffect('i', 13))
                effect = effect.pow(exp1)
                return effect
            },
            unlocked() { return hasUpgrade('n', 12) },
            canAfford() {
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && !inChallenge('c', 12)
                    && player[this.layer].points.gte(this.cost())
            },
            buy() {
                if (!hasUpgrade('r', 13)) player[this.layer].points = player[this.layer].points.sub(this.cost())
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
        21: {
            title: "Euclidean Plane",
            display() {
                return ("\nMultiply points gain by x2 per level.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Cost: " + format(this.cost()) + " numbers\n"
                    + "Effect: x" + format(this.effect()))
            },
            cost(x) {
                let cost = costWithSoftCap(x, new Decimal(1000), new Decimal(5), standardSoftcap)
                return cost.div(buyableEffect('n', 23)).div(buyableEffect('n', 32)).round()
            },
            effect(x) {
                if (hasChallenge('c', 31)) x = x.add(challengeEffect('c', 31).exp)
                let base = new Decimal(2).add(buyableEffect('n', 22))
                if (hasUpgrade('r', 35)) base = base.add(upgradeEffect('r', 35))
                if (getClickableState('i', 12) == "ON") base = base.add(clickableEffect("i", 12))
                return base.pow(x)
            },
            unlocked() { return hasUpgrade('n', 14) },
            canAfford() {
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && !inChallenge('c', 11)
                    && player[this.layer].points.gte(this.cost())
            },
            buy() {
                if (!hasUpgrade('r', 13)) player[this.layer].points = player[this.layer].points.sub(this.cost())
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
        22: {
            title: "Line",
            display() {
                return ("\nIncrease EP effect base by +1 per level, the level of this buyable can't exceed EP's level.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Cost: " + format(this.cost()) + " numbers\n"
                    + "Effect: +" + format(this.effect()))
            },
            purchaseLimit() { return getBuyableAmount('n', 21) },
            cost(x) {
                let cost = costWithSoftCap(x, new Decimal(100000), new Decimal(50), [
                    [new Decimal(20), new Decimal(1.2)],
                    [new Decimal(100), new Decimal(1.5)],
                    [new Decimal(300), new Decimal(2)],
                    [new Decimal(1000), new Decimal(3)],
                ])
                return cost.div(buyableEffect('n', 32)).round()
            },
            effect(x) {
                if (hasChallenge('c', 31)) x = x.add(challengeEffect('c', 31).exp)
                return new Decimal(x)
            },
            unlocked() { return hasUpgrade('n', 14) && hasAchievement('a', 16) },
            canAfford() {
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && !inChallenge('c', 11)
                    && player[this.layer].points.gte(this.cost())
            },
            buy() {
                if (!hasUpgrade('r', 13)) player[this.layer].points = player[this.layer].points.sub(this.cost())
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
        23: {
            title: "Circle",
            display() {
                return ("\nRecuce EP's cost by pi*level^2, the level of this buyable can't exceed EP's level.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Cost: " + format(this.cost()) + " numbers\n"
                    + "Effect: /" + format(this.effect()))
            },
            purchaseLimit() { return getBuyableAmount('n', 21) },
            cost(x) {
                let cost = costWithSoftCap(x, new Decimal(100000), new Decimal(10), [
                    [new Decimal(20), new Decimal(1.2)],
                    [new Decimal(100), new Decimal(1.5)],
                    [new Decimal(300), new Decimal(2)],
                    [new Decimal(1000), new Decimal(3)],
                ])
                return cost.div(buyableEffect('n', 32)).round()
            },
            effect(x) {
                if (hasChallenge('c', 31)) x = x.add(challengeEffect('c', 31).exp)
                let exp = new Decimal(2)
                if (hasChallenge('c', 12)) exp = exp.add(challengeEffect('c', 12).exp)
                return new Decimal(x).pow(exp).times(Math.PI).max(1)
            },
            unlocked() { return hasUpgrade('n', 14) && hasAchievement('a', 16) },
            canAfford() {
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && !inChallenge('c', 11)
                    && player[this.layer].points.gte(this.cost())
            },
            buy() {
                if (!hasUpgrade('r', 13)) player[this.layer].points = player[this.layer].points.sub(this.cost())
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
        31: {
            title: "Prime Number",
            display() {
                return ("\nMultiply number gain by the level-th prime.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Cost: " + format(this.cost()) + " numbers\n"
                    + "Effect: x" + format(this.effect()))
            },
            cost(x) {
                return new Decimal(x).factorial().times(10000).round()
            },
            effect(x) {
                let a
                if (x.eq(0)) {
                    a = new Decimal(1)
                } else if (x.lte(9591)) {
                    a = new Decimal(primeNumbers[x.sub(1).toNumber()])
                } else {
                    a = new Decimal(x).add(1).ln().times(x).add(1).round()
                }
                if (hasUpgrade('r', 31)) {
                    a = a.pow(1.5)
                }
                return a
            },
            unlocked() { return hasUpgrade('r', 21) },
            canAfford() {
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && player[this.layer].points.gte(this.cost())
            },
            buy() {
                if (!hasUpgrade('r', 13)) player[this.layer].points = player[this.layer].points.sub(this.cost())
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
        32: {
            title: "Combinatorics Model",
            display() {
                return ("\nReduce the cost of buyables in the first two rows. The cost is based on total buyables, rather than numbers.\n\n"
                    + "Level: " + format(getBuyableAmount(this.layer, this.id), 0) + '\n'
                    + "Need: " + format(this.cost()) + " buyables\n"
                    + "Effect: /" + format(this.effect()))
            },
            cost(x) {
                let cost = new Decimal(x).add(1).times(10)
                if (x.gte(10)) {
                    cost = new Decimal(x).sub(10).times(2).pow(2).add(cost)
                }
                return cost
            },
            effect(x) {
                let base = new Decimal(1.2)
                if (hasUpgrade('r', 32)) base = base.add(upgradeEffect('r', 32))
                return base.pow(x)
            },
            unlocked() { return hasUpgrade('r', 22) },
            canAfford() {
                let total = getTotalBuyables('n')
                return !(inChallenge('c', 31) && getTotalBuyables('n').gte(20))
                    && total.gte(this.cost())
            },
            buy() {
                setBuyableAmount(this.layer, this.id, getBuyableAmount(this.layer, this.id).add(1))
            },
        },
    },
    HardCap() { player.points = player.points.min(player.pointHardCap) },
    getHardCap() {
        pHC = new Decimal(100)
        ppsHC = new Decimal(100)
        if (hasUpgrade('n', 13)) {
            pHC = pHC.max(1e9)
            ppsHC = ppsHC.max(1e9)
        }
        if (hasUpgrade('n', 15)) pHC = pHC.max(1e80)
        if (hasUpgrade('n', 23)) pHC = pHC.max(1.79e308)
        if (hasChallenge('c', 22)) ppsHC = ppsHC.pow(challengeEffect('c', 22).exp)
        if (inChallenge('c', 22)) ppsHC = new Decimal(1)
        player.pointHardCap = pHC
        player.productionHardCap = ppsHC
    }
})
