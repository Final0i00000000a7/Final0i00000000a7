addLayer("r", {
    name: "Research", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "R", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 1, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() {
        return {
            unlocked: false,
            points: new Decimal(0),
        }
    },
    color: "#2B7CF0",
    requires: new Decimal(1e9), // Can be a function that takes requirement increases into account
    resource: "Research Points", // Name of prestige currency
    baseResource: "numbers", // Name of resource prestige is based on
    baseAmount() { return player.n.points }, // Get the current amount of baseResource
    type: "normal", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    exponent: 0.25, // Prestige currency exponent
    gainMult() { // Calculate the multiplier for main currency from bonuses
        mult = new Decimal(1)
        if (hasUpgrade('r', 24)) mult = mult.times(upgradeEffect('r', 24))
        if (hasUpgrade('r', 34)) mult = mult.times(upgradeEffect('r', 34))
        if (hasUpgrade('r', 42)) mult = mult.times(upgradeEffect('r', 42))
        if (hasMilestone('c', 2)) mult = mult.times(player.c.points.add(1).pow(2))
        return mult
    },
    gainExp() { // Calculate the exponent on main currency from bonuses
        let exp = new Decimal(1)
        if (hasUpgrade('r', 44)) exp = exp.times(upgradeEffect('r', 44))
        return exp
    },
    row: 1, // Row the layer is in on the tree (0 is the first row)
    hotkeys: [
        { key: "r", description: "R: Turn your numbers into research points.", onPress() { if (canReset(this.layer)) doReset(this.layer) } },
    ],
    layerShown() { return hasAchievement('a', 21) || hasUpgrade('n', 22) },
    branches: ['n'],
    passiveGeneration() {
        let base = new Decimal(0)
        if (hasMilestone('c', 3)) {
            base = base.add(new Decimal(0.1))
        }
        return base
    },
    upgrades: {
        //The first row are QOL upgrades
        11: {
            title: 'Upgrade Keeper I',
            description: 'Keep hardcap/softcap upgrades on reset.',
            cost: new Decimal(1),
            onPurchase() {
                player.n.upgrades.push(13)
                player.n.upgrades.push(15)
                player.n.upgrades.push(21)
            },
        },
        12: {
            title: 'Upgrade Keeper II',
            description: 'Keep every number upgrades on reset.',
            cost: new Decimal(100),
            unlocked() { return hasUpgrade('r', 11) }
        },
        13: {
            title: 'Automation I',
            description: 'Automatically buy number buyables, without spending.',
            cost: new Decimal(1000),
            unlocked() { return hasUpgrade('r', 12) }
        },
        14: {
            title: 'Automation II',
            description: 'Passively gain 100% number per second.',
            cost: new Decimal(25000),
            unlocked() { return hasUpgrade('r', 13) }
        },
        15: {
            title: 'Automation toggles',
            description: 'Unlocks toggles for automations.',
            cost: new Decimal(1e14),
            unlocked() { return hasUpgrade('r', 14) && hasUpgrade('r', 41) && hasUpgrade('r', 42) && hasUpgrade('r', 43) }
        },
        //other upgrades
        21: {
            title: 'Elementary Number Theory',
            description: 'Unlocks a new buyable in the Number tab.',
            cost: new Decimal(3),
            unlocked() { return hasUpgrade('r', 11) }
        },
        22: {
            title: 'Combinatorics',
            description: 'Unlocks another buyable in the Number tab.',
            cost: new Decimal(10),
            unlocked() { return hasUpgrade('r', 11) }
        },
        23: {
            title: 'Exponents',
            description: 'Raise your point production to the 1.05th power.',
            cost: new Decimal(50),
            unlocked() { return hasUpgrade('r', 21) && hasUpgrade('r', 22) },
            effect() { 
                let effect=new Decimal(1.05)
                if (getClickableState('i',21)=="ON") effect=effect.add(clickableEffect("i",21))
                return effect
            },
            effectDisplay() { return '^' + format(this.effect()) }
        },
        24: {
            title: 'Trigonometric Functions',
            description: 'Increase RP gain based on sin(time).',
            cost: new Decimal(314),
            unlocked() { return hasUpgrade('r', 21) && hasUpgrade('r', 22) },
            effect() {
                let date = new Date()
                let ms = date.getSeconds() + date.getMilliseconds() * 0.001
                let dx=new Decimal(1).add(Math.sin(Math.PI * ms))
                if (getClickableState('i',13)=="ON") dx=dx.times(clickableEffect("i",13))
                return new Decimal(1).add(dx)
            },
            effectDisplay() { return format(this.effect()) + 'x' }
        },
        31: {
            title: 'Congruence',
            description: 'Prime Number effect is raised to the 1.5th power.',
            cost: new Decimal(new Date().getFullYear()).min(2077),
            unlocked() { return hasUpgrade('r', 21) }
        },
        32: {
            title: 'Combinatorical thinking',
            description: 'Increase CM effect based on unspent RP.',
            cost: new Decimal(5000),
            unlocked() { return hasUpgrade('r', 22) },
            effect() {
                return softcap(softcap(player.r.points.pow(0.1),
                    new Decimal(10), new Decimal(0.5)),
                    new Decimal(40), new Decimal(0.2)).times(0.1)
            },
            effectDisplay() { return '+' + format(this.effect(), 4) }
        },
        33: {
            title: 'Polynomials',
            description: '"Exponents" upgrade also affects number gain.',
            cost: new Decimal(65536),
            unlocked() { return hasUpgrade('r', 23) && hasUpgrade('r', 24) },
            effect() { return upgradeEffect('r', 23) },
            effectDisplay() { return '^' + format(this.effect()) }
        },
        34: {
            title: 'Induction Method',
            description: 'Research Points boost itself.',
            cost: new Decimal(1234567),
            unlocked() { return hasUpgrade('r', 32) },
            effect() { return player.r.points.add(1).log10() },
            effectDisplay() { return format(this.effect()) + 'x' }
        },
        35: {
            title: 'Analytic Geometry',
            description: 'Addition level boost EP effect base.',
            cost: new Decimal(3333333),
            unlocked() { return hasUpgrade('r', 33) },
            effect() {
                let effect = softcap(getBuyableAmount('n', 12), new Decimal(250), new Decimal(0.75)).times(0.02)
                if (hasUpgrade('r', 43)) effect = effect.times(upgradeEffect('r', 43))
                return effect
            },
            effectDisplay() { return '+' + format(this.effect()) }
        },
        36: {
            title: 'Course',
            description: 'Unlocks Challenge.',
            cost: new Decimal(10000000),
            unlocked() { return hasUpgrade('r', 33) && hasUpgrade('r', 34) }
        },
        41: {
            title: 'Eclipse',
            description: 'If EP level <=30, raise points production to ^1.2.',
            cost: new Decimal(1e10),
            unlocked() { return hasUpgrade('r', 35) && hasChallenge('c', 12) },
            effect() { return getBuyableAmount('n', 21).lte(30) ? new Decimal(1.2) : new Decimal(1) },
            effectDisplay() { return '^' + format(this.effect()) }
        },
        42: {
            title: 'Parabola',
            description: 'If EP level is between 30 and 50, quintuple RP gain.',
            cost: new Decimal(1e11),
            unlocked() { return hasUpgrade('r', 35) && hasChallenge('c', 12) },
            effect() { return (getBuyableAmount('n', 21).gt(30) && getBuyableAmount('n', 21).lte(50)) ? new Decimal(5) : new Decimal(1) },
            effectDisplay() { return 'x' + format(this.effect()) }
        },
        43: {
            title: 'Hyperbola',
            description: 'If EP level >50, double "Analytic Geometry" effect.',
            cost: new Decimal(1e12),
            unlocked() { return hasUpgrade('r', 35) && hasChallenge('c', 12) },
            effect() { return getBuyableAmount('n', 21).gt(50) ? new Decimal(2) : new Decimal(1) },
            effectDisplay() { return 'x' + format(this.effect()) }
        },
        44: {
            title: 'Equations',
            description: '"Exponents" upgrade also affects RP gain.',
            cost: new Decimal(1e20),
            unlocked() { return hasUpgrade('r', 33) && hasChallenge('c', 22) },
            effect() { return upgradeEffect('r', 23) },
            effectDisplay() { return '^' + format(this.effect()) }
        },
        51: {
            title: 'Vector Space',
            description: 'Unlocks a new layer(Conflicts with Complex Numbers)',
            cost(){return hasUpgrade('r',52)?new Decimal(1e50):new Decimal(1e22)},
            unlocked() { return hasChallenge('c',42)||(hasUpgrade('r', 44)&&!hasUpgrade('r',52)) },
        },
        52: {
            title: 'Complex Numbers',
            description: 'Unlocks a new layer(Conflicts with Vector Space)',
            cost(){return hasUpgrade('r',51)?new Decimal(1e50):new Decimal(1e22)},
            unlocked() { return hasChallenge('c',41)||(hasUpgrade('r', 44)&&!hasUpgrade('r',51)) }
        },
    },
})