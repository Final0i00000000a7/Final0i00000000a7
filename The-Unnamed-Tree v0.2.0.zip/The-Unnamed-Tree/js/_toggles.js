addLayer("tg", {
    name: "Toggles", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "TG", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 1, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0),
            maxEP: new Decimal(999),
        }
    },
    color: "#73FBFD",
    requires: new Decimal(10), // Can be a function that takes requirement increases into account
    resource: "Toggles", // Name of prestige currency
    type: "none", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    row: 'side', // Row the layer is in on the tree (0 is the first row)
    layerShown() { return hasUpgrade('r', 15) },
    tooltip() { return 'Toggles for automations' },
    tabFormat: [
        ["display-text", "Number Buyable Automation"],
        "blank",
        ["row", [["clickable", 11],
            "blank",
        ["column", [["display-text","Maximum EP amount(-1 means Infinity)"],
        ["text-input", "maxEP"]
        ]]
        ]]
    ],
    clickables: {
        11: {
            title: "Mode",
            display() { return getClickableState(this.layer, this.id) },
            canClick() { return true },
            unlocked() { return hasUpgrade('r', 13) },
            onClick() {
                if (getClickableState(this.layer, this.id) != "ON") {
                    setClickableState(this.layer, this.id, "ON")
                } else {
                    setClickableState(this.layer, this.id, "OFF")
                }
            }
        }
    },
    normalizeClickable() {
        for (let i in player.tg.clickables) {
            if (getClickableState('tg', i) != "OFF") setClickableState('tg', i, "ON")
        }
    }
})