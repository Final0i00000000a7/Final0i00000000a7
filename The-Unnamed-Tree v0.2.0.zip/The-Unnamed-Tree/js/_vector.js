addLayer("v", {
    name: "Vector Space", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "V", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 2, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0),
            maxDimensions: 3,
            totalshifts: new Decimal(0)
        }
    },
    color: "#56C46F",
    requires: new Decimal(10), // Can be a function that takes requirement increases into account
    resource: "Scalars", // Name of prestige currency
    baseResource: "numbers", // Name of resource prestige is based on
    baseAmount() { return player.n.points }, // Get the current amount of baseResource
    type: "none", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    row: 1, // Row the layer is in on the tree (0 is the first row)
    layerShown() { return hasUpgrade('r', 51) },
    branches: ['n'],
    effect() { 
        let exp=new Decimal(0.5)
        if(hasUpgrade('v',14)) exp=exp.add(0.1)
        if(hasChallenge('c',41)) exp=exp.add(0.1)
        return softcap(player[this.layer].points.add(1).pow(exp),new Decimal(1e9),new Decimal(0.4)) 
    },
    effectDescription() { return "Multiplying number gain by x" + format(this.effect()) },
    tabFormat: [
        "main-display",
        "blank",
        ["display-text", "R<sup>1</sup> will produce Scalars, and other dimensions will produce lower dimensions."],
        ["display-text", () => { return "You have " + format(player.r.points) + " Research Points" }],
        ["display-text", () => { if(hasUpgrade('v',13)) return "Tickspeed: x"+format(buyableEffect('v',11)) }],
        ["display-text", () => { if(inChallenge('c',41)) return "You are producing "+format(gridEffect('v', 101).pow(0.2))+" Numbers per second" }],
        "blank",
        "buyables",
        "grid",
        "clickables",
        "upgrades"
    ],
    automate() {
        if (hasUpgrade('v', 14)) {
            buyBuyable('v', 11)
            for (let i in player.v.grid) {
                if(player.v.maxDimensions*100+2>i){
                    for(let j=0;j<10;++j)
                        tmp.v.grid.onClick(player.v.grid[i],i)
                }
            }
        }
    },
    grid: {
        rows() { return player.v.maxDimensions },
        maxRows: 8,
        cols: 1,
        getStartData(id) {
            return {
                amount: new Decimal(0),
                freeAmount: new Decimal(0)
            }
        },
        getUnlocked(id) {
            return (id == 101 || ((player.v.maxDimensions * 100 + 1) >= id && getGridData('v', id - 100).amount.gte(1)))
        },
        getTitle(data, id) {
            return "R<sup>" + ((id - 1) / 100).toFixed(0) + "</sup> x"
                + format(this.getMultiplier(data, id))
        },
        getDisplay(data, id) {
            return ("Amount: " + format(data.amount, 0) + "(+" + format(data.freeAmount) + ")<br>"
                + "Generating " + format(gridEffect('v', id))
                + (id == 101 ? " Scalars" : " R<sup>" + ((id - 101) / 100).toFixed(0) + "</sup>")
                + " per second<br>"
                + "Cost: " + format(this.getCost(data, id)) + (id == 101 ? " Research Points" : " Scalars"))

        },
        getCost(data, id) {
            let dim = (id - 101) / 100
            return costWithSoftCap(data.amount, dimBase[dim], dimExp[dim], standardSoftcap)
        },
        getMultiplier(data, id) {
            let mult = new Decimal(1)
            if (hasUpgrade('v', 11)) mult = new Decimal(2).pow(data.amount).times(mult)
            mult = new Decimal(2).pow(player.v.totalshifts.sub(Math.max((id - 301) / 100, 0))).times(mult)
            mult = mult.times(buyableEffect('v',11))
            if (hasMilestone('c',4)) mult=mult.times(player.c.points.add(1).pow(0.5))
            if (hasUpgrade('v',16)&&id==801) mult=mult.times(upgradeEffect('v',16))
            if (hasChallenge('c',41)&&id==801) mult=mult.times(challengeEffect('c',41).exp)
            return mult
        },
        getCanClick(data, id) {
            let uselayer = (id == 101 ? 'r' : 'v')
            return player[uselayer].points.gte(this.getCost(data, id))
        },
        onClick(data, id) {
            if (this.getCanClick(data, id)) {
                let uselayer = (id == 101 ? 'r' : 'v')
                if(!hasUpgrade('v',14))player[uselayer].points = player[uselayer].points.sub(this.getCost(data, id))
                player.v.grid[id].amount = player.v.grid[id].amount.add(1)
            }
        },
        onHold(data,id){this.onClick(data,id)},
        getEffect(data, id) {
            if (data == null) return new Decimal(0)
            return data.amount.add(data.freeAmount).div((id - 1) / 50 - 1).times(this.getMultiplier(data, id))
        },
        getStyle(data, id) {
            return {
                "width": "480px",
                "height": "80px"
            }
        }
    },
    upgrades: {
        11: {
            title: 'Dimension Self-Synergy',
            description: 'Increase production by x2.00 for each bought dimension',
            cost: new Decimal(100),
            unlocked() { return true }
        },
        12: {
            title: 'Dimensional Shift',
            description: 'Unlocks Dimensional Shift',
            cost: new Decimal(1e9),
            unlocked() { return hasUpgrade('v', 11) }
        },
        13: {
            title: 'Tickspeed Upgrades',
            description: 'Unlocks Tickspeed Upgrades',
            cost: new Decimal(1e11),
            unlocked() { return hasUpgrade('v', 12) && player.v.totalshifts.gte(1) }
        },
        14: {
            title: 'Dimension Automation',
            description: 'Autobuys each dimension without spending',
            cost: new Decimal(1e20),
            unlocked() { return hasUpgrade('v', 13) && player.v.totalshifts.gte(2) }
        },
        15: {
            title: 'Scalar Effect Bonus',
            description: 'Scalar effect exponent 0.5->0.6',
            cost: new Decimal(1e30),
            unlocked() { return hasUpgrade('v', 13) && player.v.totalshifts.gte(3) }
        },
        16: {
            title: 'Vector-Complex Synergy',
            description: 'Increases R<sup>8</sup> production based on iP',
            cost: new Decimal(1e55),
            effect() { return player.i.points.add(1).log10() },
            effectDisplay() { return "x" + format(this.effect()) },
            unlocked() { return hasUpgrade('v', 15) && player.v.totalshifts.gte(5) && hasUpgrade('r',52) }
        },
    },
    buyables: {
        11: {
            title: "Tickspeed Upgrades",
            cost(x) { return costWithSoftCap(x, new Decimal(1e10), new Decimal(10), standardSoftcap) },
            display() {
                return "Multiplying Each dimension by x1.1<br>"
                    + "Cost: " +format(this.cost())+ " Scalars"
            },
            effect(x){return new Decimal(1.1).pow(x)},
            unlocked(){return hasUpgrade('v',13)},
            canAfford() { return player.v.points.gte(this.cost()) },
            buy() {
                if(!hasUpgrade('v',14))player.v.points = player.v.points.sub(this.cost())
                setBuyableAmount('v', this.id, getBuyableAmount('v', this.id).add(1))
            },
            style:{
                "width": "480px",
                "height": "80px"
            }
        },
    },
    clickables: {
        11: {
            title() { return "DIMENSIONAL " + (player.v.maxDimensions < 8 ? "SHIFT" : "BOOST") },
            display() {
                return "Reset all dimensions, unlocks a new Dimension, and boost all dimensions by x2.00<br>" +
                    "Require: 3 R<sup>" + player.v.maxDimensions.toString() + "</sup>"
            },
            canClick() { return (player.v.maxDimensions<8)&&getGridData('v', 100 * player.v.maxDimensions + 1).amount.gte(3) },
            unlocked() { return hasUpgrade('v', 12) },
            style: {
                "width": "200px",
                "height": "120px"
            },
            onClick() { dimShift() }
        }
    },
    update(diff) {
        player.v.points = player.v.points.add(gridEffect('v', 101).times(diff))
        if(inChallenge('c',41))player.n.points = player.n.points.add(gridEffect('v', 101).pow(0.2).times(diff))
        for (let i = 1; i < 8; ++i) {
            player.v.grid[i * 100 + 1].freeAmount = player.v.grid[i * 100 + 1].freeAmount.add(gridEffect('v', i * 100 + 101).times(diff))
        }
    },
})