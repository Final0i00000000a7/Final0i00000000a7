var dimBase = [
    new Decimal(1e16), new Decimal(10),
    new Decimal(1000), new Decimal(1e6),
    new Decimal(1e10), new Decimal(1e16),
    new Decimal(1e25), new Decimal(1e40),
]
var dimExp = [
    new Decimal(100), new Decimal(100),
    new Decimal(1000), new Decimal(10000),
    new Decimal(1e5), new Decimal(1e7),
    new Decimal(1e10), new Decimal(1e15),
]
var standardSoftcap = [
    [new Decimal(10), new Decimal(1.2)],
    [new Decimal(100), new Decimal(1.5)],
    [new Decimal(300), new Decimal(2)],
    [new Decimal(1000), new Decimal(3)],
]

var primeNumbers = [2]
function getPrimeNumber() {
    for (let i = 3; i < 100000; ++i) {
        isprime = true
        for (j = 0; primeNumbers[j] * primeNumbers[j] <= i; ++j) {
            if (i % primeNumbers[j] == 0) {
                isprime = false
            }
        }
        if (isprime) {
            primeNumbers.push(i)
        }
    }
}
getPrimeNumber()
function costWithSoftCap(x, base, exp, caps = standardSoftcap) {
    let r = new Decimal(x)
    let scLevel = 0
    for (let j = 0; j < caps.length; ++j) {
        if (x.gte(caps[j][0])) {
            ++scLevel
        }
    }
    if (scLevel != 0) {
        r = new Decimal(caps[0][0])
        for (let j = 0; j < scLevel - 1; ++j) {
            r = caps[j + 1][0].sub(caps[j][0]).pow(caps[j][1]).add(r)
        }
        r = x.sub(caps[scLevel - 1][0]).pow(caps[scLevel - 1][1]).add(r)
    }
    return exp.pow(r).times(base)
}
function getTotalBuyables(layer) {
    let total = new Decimal(0)
    for (let i in player[layer].buyables) {
        total = total.add(getBuyableAmount('n', i))
    }
    return total
}
function HardCap() { player.points = player.points.min(player.pointHardCap) }
function getHardCap() {
    pHC = new Decimal(100)
    ppsHC = new Decimal(100)
    if (hasUpgrade('n', 13)) {
        pHC = pHC.max(1e9)
        ppsHC = ppsHC.max(1e9)
    }
    if (hasUpgrade('n', 15)) {
        pHC = pHC.max(1e80)
    }
    player.pointHardCap = pHC
    player.productionHardCap = ppsHC
}
function getRKS(score, goal) {
    let rks = score.gte(goal) ? score.log10().div(goal.log10()) : new Decimal(0)
    rks = softcap(rks, new Decimal(4), 0.5)
    return rks
}
function inAnyChallenge() {
    for (let i in player.c.challenges) {
        if (inChallenge('c', i)) return true
    }
    return false
}
function getSuperSoftcap() {
    return new Decimal(10).pow(player.productionHardCap.log10().pow(2))
}
function dimShift() {
    if (tmp.v.clickables[11].canClick) {
        player.v.totalshifts = player.v.totalshifts.add(1)
        if (player.v.maxDimensions < 8) player.v.maxDimensions++
    }
    for (let i = 0; i < 8; ++i) {
        setGridData('v', 100 * i + 101, { amount: new Decimal(0), freeAmount: new Decimal(0) })
    }
    setBuyableAmount('v', 11, new Decimal(0))
    player.v.points = new Decimal(0)
}