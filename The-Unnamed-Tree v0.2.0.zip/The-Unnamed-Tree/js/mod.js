let modInfo = {
	name: "The Mathematical Research Tree",
	id: "thexxxtree1",
	author: "FiveYearGaoKao",
	pointsName: "points",
	modFiles: ["_number.js",
		"_research.js",
		"_achievements.js",
		"_course.js",
		"_toggles.js",
		"_vector.js",
		"_complex.js",
		"_infinity.js",
		"functions.js",
		"tree.js"],
	discordName: "",
	discordLink: "",
	initialStartPoints: new Decimal(10), // Used for hard resets and new players
	offlineLimit: 1,  // In hours
}

// Set your version in num and name
let VERSION = {
	num: "0.2.0",
	name: "To the Infinity",
}

let changelog = `<h1>Changelog:</h1><br>
	<h3>v0.2.0:To the Infinity</h3><br>
		- Added 4 more Challenges.<br>
		- Added Vector Space(Antimatter Dimensions).<br>
		- Added Complex Number<br>
		- Added Infinity reset.<br>
		Current Endgame:1.79e308 points,>40.00rks
	<h3>v0.1.0:Rework</h3><br>
		- Added points.<br>
		- Added Numbers.<br>
		- Added Research.<br>
		- Added Challenge.<br>
		Current Endgame:1e110 points,7.00rks`

let winText = `Congratulations! You have reached the end and beaten this game, but for now...`

// If you add new functions anywhere inside of a layer, and those functions have an effect when called, add them here.
// (The ones here are examples, all official functions are already taken care of)
var doNotCallTheseFunctionsEveryTick = [
	"costWithSoftcap","getPrimeNumber","getTotalBuyables",
	"getSuperSoftcap",
	"getRKS","inAnyChallenge",
	"getCost","getMultiplier","dimShift",
	"getIPGen","getTotalActivate","getIPexp",
	"blowUpEverything"]

function getStartPoints() {
	return new Decimal(modInfo.initialStartPoints)
}

// Determines if it should show points/sec
function canGenPoints() {
	return true
}

// Calculate points/sec!
function getPointGen() {
	if (!canGenPoints())
		return new Decimal(0)

	let gain = new Decimal(0)
		.add(buyableEffect('n', 11))
		.add(buyableEffect('n', 12))
		.times(buyableEffect('n', 13))
		.times(buyableEffect('n', 21))
	if (hasUpgrade('r', 23)) gain = gain.pow(upgradeEffect('r', 23))
	if (hasUpgrade('r', 41)) gain = gain.pow(upgradeEffect('r', 41))
	if (layerunlocked('i')) gain = gain.pow(1-player.i.direction/90).times(Math.cos(player.i.direction * Math.PI / 180))
	if (hasMilestone('c',6)&&inAnyChallenge()) gain = gain.pow(player.c.points.sub(11).times(0.05).add(1).min(1.10))
	if (getClickableState('i',11)=="ON") gain=gain.times(clickableEffect("i",11))
	if (hasMilestone('c', 0)) gain = gain.times(player.c.points.add(1).pow(8))
	if (hasUpgrade('n', 21)) {
		gain = softcap(gain, player.productionHardCap, new Decimal(0.5))
		gain = softcap(gain, getSuperSoftcap(), new Decimal(0.4))
	} else {
		gain = gain.min(player.productionHardCap)
	}
	if (player.points.gt(player.pointHardCap)) {
		gain = new Decimal(0)
		player.points = player.pointHardCap
	}
	return gain
}

// You can add non-layer related variables that should to into "player" and be saved here, along with default values
function addedPlayerData() {
	return {
		pointHardCap: new Decimal(100),
		productionHardCap: new Decimal(100),
	}
}

// Display extra things at the top of the page
var displayThings = [() => { return "Your points amount is HARDCAPPED at " + format(player.pointHardCap) + "!" },
() => { return "Your points production is " + (hasUpgrade('n', 21) ? "SOFTCAPPED" : "HARDCAPPED") + " at " + format(player.productionHardCap) + "!" },
() => { if (hasUpgrade('n', 23)) return "Your points production is SUPER SOFTCAPPED at " + format(getSuperSoftcap()) + "!" },
]

// Determines when the game "ends"
function isEndgame() {
	return player.inf.points.gte(1)
}



// Less important things beyond this point!

// Style for the background, can be a function
var backgroundStyle = {

}

// You can change this if you have things that can be messed up by long tick lengths
function maxTickLength() {
	return (3600) // Default is 1 hour which is just arbitrarily large
}

// Use this if you need to undo inflation from an older version. If the version is older than the version that fixed the issue,
// you can cap their current resources with this.
function fixOldSave(oldVersion) {
}